import os
from pathlib import Path
from datetime import datetime

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.models.baseoperator import chain
from airflow.providers.google.cloud.operators.bigquery import (
    BigQueryCreateEmptyDatasetOperator,
    BigQueryCreateEmptyTableOperator,
    BigQueryExecuteQueryOperator,
)
from airflow.providers.google.cloud.transfers.local_to_gcs import (
    LocalFilesystemToGCSOperator,
)
from airflow.providers.google.cloud.transfers.gcs_to_bigquery import (
    GCSToBigQueryOperator,
)
from google.cloud import storage

storage.blob._DEFAULT_CHUNKSIZE = 5 * 1024 * 1024  # 5 MB
storage.blob._MAX_MULTIPART_SIZE = 5 * 1024 * 1024  # 5 MB

base_path = Path(__file__).parents[1]
data_file = os.path.join(base_path, "data", "netflixdata.csv")

PROJECT_ID = os.environ.get("GCP_PROJECT_ID")
gcp_bucket = os.environ.get("GCP_GCS_BUCKET")

bq_dataset = "netflixdata"
bq_table = "netflix"

gcp_data_dest = "data/netflixData.csv"

with DAG(
    "data_ingestion_local_gcs_netflix",
    description="Example DAG showcasing loading and transforming data with BigQuery.",
    doc_md=__doc__,
    schedule_interval=None,
    start_date=datetime(2021, 1, 1),
    catchup=False,
) as dag:

    upload_netflix_data = LocalFilesystemToGCSOperator(
        task_id="upload_netflix_data",
        src=data_file,
        dst=gcp_data_dest,
        bucket=gcp_bucket,
    )

    create_temp_table = BigQueryCreateEmptyTableOperator(
        task_id="create_temp_table",
        dataset_id=bq_dataset,
        table_id=f"{bq_table}_temp",
        schema_fields=[
            {"name": "show_id", "type": "STRING", "mode": "NULLABLE"},
            {"name": "type", "type": "STRING", "mode": "NULLABLE"},
            {"name": "title", "type": "STRING", "mode": "NULLABLE"},
            {"name": "director", "type": "STRING", "mode": "NULLABLE"},
            {"name": "cast", "type": "STRING", "mode": "NULLABLE"},
            {"name": "country", "type": "STRING", "mode": "NULLABLE"},
            {"name": "date_added", "type": "STRING", "mode": "NULLABLE"},
            {"name": "release_year", "type": "INTEGER", "mode": "NULLABLE"},
            {"name": "rating", "type": "STRING", "mode": "NULLABLE"},
            {"name": "duration", "type": "STRING", "mode": "NULLABLE"},
            {"name": "listed_in", "type": "STRING", "mode": "NULLABLE"},
            {"name": "description", "type": "STRING", "mode": "NULLABLE"},
        ],
    )

    # Transformation: Replace missing or empty values in the "country" column with "NA"
    transformation_query = """
    UPDATE `{project}.{dataset}.{table}_temp`
    SET country = 'NA'
    WHERE country IS NULL OR TRIM(country) = ''
    """.format(
        project=PROJECT_ID, dataset=bq_dataset, table=bq_table
    )

    transformation_task = BigQueryExecuteQueryOperator(
        task_id="transformation_task",
        sql=transformation_query,
        use_legacy_sql=False,
    )

    transfer_netflix_data = GCSToBigQueryOperator(
        task_id="netflix_gcs_to_bigquery",
        bucket=gcp_bucket,
        source_objects=[gcp_data_dest],
        skip_leading_rows=1,
        destination_project_dataset_table="{}.{}.{}".format(PROJECT_ID, bq_dataset, bq_table),
        schema_fields=[
            {"name": "show_id", "type": "STRING", "mode": "NULLABLE"},
            {"name": "type", "type": "STRING", "mode": "NULLABLE"},
            {"name": "title", "type": "STRING", "mode": "NULLABLE"},
            {"name": "director", "type": "STRING", "mode": "NULLABLE"},
            {"name": "cast", "type": "STRING", "mode": "NULLABLE"},
            {"name": "country", "type": "STRING", "mode": "NULLABLE"},
            {"name": "date_added", "type": "STRING", "mode": "NULLABLE"},
            {"name": "release_year", "type": "INTEGER", "mode": "NULLABLE"},
            {"name": "rating", "type": "STRING", "mode": "NULLABLE"},
            {"name": "duration", "type": "STRING", "mode": "NULLABLE"},
            {"name": "listed_in", "type": "STRING", "mode": "NULLABLE"},
            {"name": "description", "type": "STRING", "mode": "NULLABLE"},
        ],
        source_format="CSV",
        create_disposition="CREATE_NEVER",  # No need to create the table, assuming it already exists
        write_disposition="WRITE_APPEND",  # Append data to the existing table
        allow_jagged_rows=True,
    )

    begin = DummyOperator(task_id="begin")
    end = DummyOperator(task_id="end")
    chain(
        begin,
        upload_netflix_data,
        create_temp_table,
        transformation_task,
        transfer_netflix_data,
        end,
    )
